import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class InterviewExperienceService {

  constructor() {}
//   items:  [];

// //   addToForm(product: Product) {
// //     this.items.push(product);
// //   }

//   getItems() {
//     return this.items;
//   }

//   clearForm() {
//     this.items = [];
//     return this.items;
//   }

}